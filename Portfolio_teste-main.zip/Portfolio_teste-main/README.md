
https://portfolio-maio.netlify.app/
________________________________________________________

https://beacons.ai/robertsmaio
________________________________________________________

    Estou desenvolvendo um site para conseguir evoluir nos meus estudos e para que possiveis empresas e pessoas vejam meu desenvolvimento.


  WEB LAYOUT
 ________________________________________________________
  
![Screenshot_1](https://user-images.githubusercontent.com/112484674/194781299-a0282721-faf2-49d2-b844-dec57f7b748c.png)
![image](https://user-images.githubusercontent.com/112484674/193478902-f74b0338-4b19-4c01-95a2-08565202cf1e.png)


 Tecnologias utilizadas
_________________________________________________________
- HTML5
- CSS3
- PHP


  Implantação em produção
_________________________________________________________
Front end web: Netlify



  Autor
_________________________________________________________
Robert de Siqueira Maio 

  https://www.linkedin.com/in/robert-s-maio-62b38019a/
